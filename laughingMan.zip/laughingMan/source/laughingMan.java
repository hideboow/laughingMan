import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.video.*; 
import gab.opencv.*; 
import java.awt.Rectangle; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class laughingMan extends PApplet {


/*
project name:laughingMan
createBy:hidenori

<<\u6982\u8981>>
\u2460PC\u306e\u5185\u81d3\u30ab\u30e1\u30e9\u3092\u8d77\u52d5\u3057\u3001\u4eba\u306e\u9854\u3092\u691c\u77e5\u3059\u308b\u3002
\u2461\u691c\u77e5\u3057\u305f\u9854\u306e\u30b5\u30a4\u30ba\u306b\u3001\u653b\u6bbb\u6a5f\u52d5\u968a\u306e\u7b11\u3044\u7537\u753b\u50cf\u3092\u5f53\u3066\u308b\u3002
\u2462\u7b11\u3044\u7537\u306e\u30d1\u30fc\u30c4\u306f\u3001\u56de\u8ee2\u90e8\u5206\u3068\u9854\u90e8\u5206\u306e\uff12\u3064\u3002
\u2463\u56de\u8ee2\u90e8\u5206\u306f\u3001\u53f3\u56de\u8ee2\u3092\u3055\u305b\u306a\u304c\u3089\u8868\u793a\u3055\u305b\u308b\u3002

<<\u30dd\u30a4\u30f3\u30c8>>
\u2460\u7b11\u3044\u7537\u306e\u80cc\u666f\u90e8\u5206\u306e\u307f\u3092\u56de\u8ee2\u3055\u305b\u308b\u305f\u3081\u3001laughFace\u306b\u5bfe\u3057\u3066\u306frotate\u3092\u6253\u3061\u6d88\u3057\u3066\u304b\u3089\u63cf\u753b\u3002
\u2461\uff12\u679a\u306e\u5186\u5f62\u753b\u50cf\u3092\u91cd\u306d\u5408\u308f\u305b\u308b\u305f\u3081\u63cf\u753b\u306fcenter\u30e2\u30fc\u30c9\u304c\u697d\u3002	

*/


//------------------------------------------------------------------
 // Video\u3092\u6271\u3046\u30e9\u30a4\u30d6\u30e9\u30ea
//openCV\u30e9\u30a4\u30d6\u30e9\u30ea
//\u9854\u8a8d\u8b58\u6642\u306e\u56db\u89d2\u5f62\u7528\u30e9\u30a4\u30d6\u30e9\u30ea

//------------------------------------------------------------------
Capture camera; // \u30e9\u30a4\u30d6\u30ab\u30e1\u30e9\u306e\u6620\u50cf\u3092\u3042\u3064\u304b\u3046Capture\u578b\u306e\u5909\u6570
OpenCV opencv;
Rectangle[] faces;//\u9854\u8a8d\u8b58\u7d50\u679c\u3092\u683c\u7d0d\u3059\u308b\u914d\u5217\u5909\u6570
PImage laughFace;
PImage laughRing;
float roll;//\u56de\u8ee2\u901f\u5ea6\u5909\u6570

//------------------------------------------------------------------
public void setup() {
	size(640, 480);
	frameRate(60);

	//\u30ab\u30e1\u30e9\u8d77\u52d5+\u9854\u8a8d\u8b58\u8a2d\u5b9a
	camera = new Capture(this, width, height,12);
  	opencv = new OpenCV(this,camera);
  	opencv.loadCascade(OpenCV.CASCADE_FRONTALFACE); 
  	camera.start();

  	//\u7b11\u3044\u7537\u753b\u50cf\u306e\u547c\u3073\u51fa\u3057
  	laughFace = loadImage("data/faceParts.png");
  	laughRing = loadImage("data/ringParts.png");
  	imageMode(CENTER);//\u5186\u5f62\u306e\u753b\u50cf\u3092\u91cd\u306d\u5408\u308f\u305b\u308b\u306e\u3067\u3001\u4e2d\u5fc3\u70b9\u304b\u3089\u63cf\u753b\u3059\u308b\u3002
  	roll = 0;
}

//------------------------------------------------------------------
public void draw() {
	
	opencv.loadImage(camera);
  	image(camera, width/2, height/2);//\u753b\u9762\u4e2d\u5fc3\u90e8\u3092\u539f\u70b9\u306b\u30ab\u30e1\u30e9\u304b\u3089\u306e\u753b\u50cf\u3092\u63cf\u753b
  	faces = opencv.detect();//\u8aad\u307f\u8fbc\u3093\u3060cascade\u3092\u5143\u306b\u3001\u9854\u8a8d\u8b58
  	roll += 0.4f;//\u56de\u8ee2\u901f\u5ea6\u3092\u8a2d\u5b9a
  	
  	//\u8a8d\u8b58\u3057\u305f\u7b87\u6240\u306b\u7b11\u3044\u7537\u3092\u8868\u793a\u3059\u308b
	if(faces.length != 0){
		for (int i = 0; i < faces.length; i++) {
	    	translate(faces[i].x+faces[i].width/2,faces[i].y+faces[i].height/2);//\u7b11\u3044\u7537\u753b\u50cf\u306f\u9854\u306e\u4e2d\u5fc3\u90e8\u3092\u539f\u70b9\u306b\u63cf\u753b
	    	rotate(roll);
	    	image(laughRing, 0, 0, faces[i].width*1.5f, faces[i].height*1.5f);
	    	rotate(-roll);//face\u90e8\u5206\u306f\u56de\u8ee2\u3055\u305b\u306a\u3044\u306e\u3067\u3001-\u56de\u8ee2\u3067\u6253\u3061\u6d88\u3059
	    	image(laughFace, 0, 0, faces[i].width*1.3f, faces[i].height*1.3f);
	    }
	}
	saveFrame("frames/####.png");//\u5b9f\u884c\u7d50\u679c\u3092\u4fdd\u5b58\u3059\u308b
}

//------------------------------------------------------------------
//\u30ab\u30e1\u30e9\u306e\u6620\u50cf\u304c\u66f4\u65b0\u3055\u308c\u308b\u305f\u3073\u306b\u3001\u6700\u65b0\u306e\u6620\u50cf\u3092\u8aad\u307f\u8fbc\u3080
public void captureEvent(Capture camera) {
    camera.read();
}

//------------------------------------------------------------------
// void keyPressed(){
// 	if (key ==' ') {
// 		movie.finish();
// 		exit();
// 	}
// }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--full-screen", "--bgcolor=#666666", "--stop-color=#cccccc", "laughingMan" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
